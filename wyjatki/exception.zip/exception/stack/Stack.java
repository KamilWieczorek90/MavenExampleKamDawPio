package programator02.exception.stack;

public class Stack implements IStack{

    private int[] stack;
    private int topOfStack;

    public Stack(int size){
        stack = new int[size];
        topOfStack = -1;
    }

    public void push(int element) throws StackOverflowException{
        if(topOfStack == stack.length - 1){
            throw new StackOverflowException(topOfStack+1);
        } else {
            stack[++topOfStack] = element;
        }
    }
    public int pop() throws StackEmptyException {
        if (topOfStack < 0){
            throw new StackEmptyException();
        } else{
            return stack[topOfStack--];
        }
    }
}
