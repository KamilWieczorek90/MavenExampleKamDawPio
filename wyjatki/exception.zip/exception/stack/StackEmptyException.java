package programator02.exception.stack;

public class StackEmptyException extends Exception{
}
